import os
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from PIL import Image, ImageTk
import cv2
import threading

def validate_password():
    password = simpledialog.askstring("Password Required", "Enter password:", show='*')
    if password != "1254":
        messagebox.showerror("Error", "Invalid password")
        root.quit()
        return False
    return True

# Material Design Theme Colors
COLOR_PRIMARY = "#0aa092"
COLOR_SECONDARY = "#03DAC6"
COLOR_BACKGROUND = "#121212"
COLOR_SURFACE = "#1E1E1E"
COLOR_ERROR = "#dd0011"
COLOR_SUCCESS = "#69F0AE"
COLOR_TEXT_PRIMARY = "#ffffff"
COLOR_TEXT_SECONDARY = "#0053f6"

# File path for saving commands persistently
SAVED_COMMANDS_FILE = "saved_commands.txt"

# Audio, Camera, Quality and Bitrate options 
AUDIO_OPTIONS = ["No Audio","Audio On", "Mic Audio"]
CAMERA_OPTIONS = ["Camera Off", "Front Camera", "Back Camera"] 
QUALITY_OPTIONS = ["240p", "360p", "480p", "720p", "Highest"]
BITRATE_OPTIONS = ["1M", "2M", "4M", "6M", "Highest"]

class MaterialStyle:
    """Material Design styling configuration with improved readability"""
    def __init__(self):
        self.style = ttk.Style()
        
        # Base frame style
        self.style.configure("Material.TFrame",
                           background=COLOR_SURFACE)
        
        # Label styles with optimized fonts
        self.style.configure("Material.TLabel",
                           background=COLOR_SURFACE,
                           foreground=COLOR_TEXT_PRIMARY,
                           padding=(5, -3),
                           font=("Segoe UI Semibold", 13))  # Semibold for better readability
        
        self.style.configure("MaterialHeader.TLabel",
                           background=COLOR_SURFACE,
                           foreground=COLOR_TEXT_PRIMARY,
                           font=("Segoe UI", 11, "bold"))  # Slightly reduced but still prominent
        
        # Button styles with improved contrast and compact padding
        self.style.configure("Material.TButton",
                           background=COLOR_PRIMARY,
                           foreground="green",
                           padding=(8, 3),  # Reduced padding
                           font=("Segoe UI", 9, "bold"))  # Bold for better visibility
        
        self.style.configure("MaterialSecondary.TButton",
                           background=COLOR_SECONDARY,
                           foreground="green",
                           padding=(8, 3),
                           font=("Segoe UI", 9, "bold"))
        
        # Checkbox style with compact design
        self.style.configure("Material.TCheckbutton",
                           background=COLOR_SURFACE,
                           foreground=COLOR_TEXT_PRIMARY,
                           font=("Segoe UI", 11))
        
        # Combobox with improved readability
        self.style.configure("Material.TCombobox",
                           background=COLOR_SURFACE,
                           foreground="green",
                           padding=(4, 2),  # Reduced padding
                           font=("Segoe UI", 9))  # Smaller but still readable

def get_connected_devices():
    try:
        result = subprocess.run(["adb", "devices"], capture_output=True, text=True)
        devices = []
        for line in result.stdout.split('\n')[1:]:  # Skip first line (header)
            if line.strip() and not line.startswith('*'):
                device_id = line.split('\t')[0]
                devices.append(device_id)
        return devices
    except Exception as e:
        print(f"Error getting devices: {e}")
        return []

def update_device_list():
    devices = get_connected_devices()
    device_dropdown['values'] = devices
    if devices and not device_var.get():
        device_var.set(devices[0])  # Select first device by default
    elif not devices:
        device_var.set('')

def update_output(result):
    output_text.config(state=tk.NORMAL)
    output_text.delete("1.0", tk.END)
    if result.returncode == 0:
        output_text.insert(tk.END, f"Success:\n{result.stdout}", 'success')
    else:
        output_text.insert(tk.END, f"Error:\n{result.stderr}", 'error')
    output_text.config(state=tk.DISABLED)

def execute_commands():
    def run_scrcpy():
        selected_device = device_var.get()
        if not selected_device:
            messagebox.showerror("Error", "No device selected")
            return
            
        commands = ["scrcpy", "-s", selected_device]
        
        # Handle audio options
        audio_selection = audio_var.get()
        if audio_selection == "No Audio":
            commands.append("--no-audio")
        elif audio_selection == "Mic Audio":
            commands.append("--audio-source=mic")
        elif audio_selection == "Audio On":
            commands += (["--audio-source=playback","--audio-dup","--audio-bit-rate=64000","--audio-codec=opus","--audio-buffer=10","--render-driver=opengl"])            
        # Handle quality options
        quality_selection = quality_var.get()
        if quality_selection != "Highest":
            quality_value = int(quality_selection.replace("p", ""))
            commands.append(f"--max-fps=30")
            commands.append(f"--max-size={quality_value}")
        
        # Handle bitrate options
        bitrate_selection = bitrate_var.get()
        if bitrate_selection != "Highest":
            commands.append(f"--video-bit-rate={bitrate_selection}")
        # Handle camera options
        camera_selection = camera_var.get()
        if camera_selection == "Front Camera":
            commands.append("--video-source=camera")
            commands.append("--camera-facing=front")
        elif camera_selection == "Back Camera":
            commands.append("--video-source=camera")
            commands.append("--camera-facing=back")
            
        if fullscreen_var.get():
            commands.append("--fullscreen")
        if show_touches_var.get():
            commands.append("--show-touches")
        if turn_screen_off_var.get():
            commands.append("--turn-screen-off")
        if rotate_screen_var.get():
            commands.append("--capture-orientation=flip90")
        if no_control_var.get():
            commands.append("--no-control")
        if screen_recording_var.get():
            commands.append("--record=screen_record.mp4")

        result = subprocess.run(commands, shell=True, capture_output=True)
        
        # Update GUI in the main thread
        root.after(0, lambda: update_output(result))
    
    # Start scrcpy in a separate thread
    threading.Thread(target=run_scrcpy, daemon=True).start()

def refresh_devices():
    update_device_list()

def stop_scrcpy():
    def run_stop():
        result = subprocess.run(["taskkill", "/F", "/IM", "scrcpy.exe"], shell=True, text=True, capture_output=True)
        root.after(0, lambda: update_output(result))
    
    threading.Thread(target=run_stop, daemon=True).start()

def execute_command(command, use_device=True):
    if command.strip():
        try:
            selected_device = device_var.get() if use_device else None
            if selected_device and 'adb' in command:
                # Insert -s device_id after 'adb' in the command
                cmd_parts = command.split()
                adb_index = cmd_parts.index('adb')
                cmd_parts.insert(adb_index + 1, '-s')
                cmd_parts.insert(adb_index + 2, selected_device)
                command = ' '.join(cmd_parts)
            
            result = subprocess.run(command, shell=True, text=True, capture_output=True)
            output_text.config(state=tk.NORMAL)
            output_text.delete("1.0", tk.END)
            if result.returncode == 0:
                output_text.insert(tk.END, f"Success:\n{result.stdout}", 'success')
            else:
                output_text.insert(tk.END, f"Error:\n{result.stderr}", 'error')
            output_text.config(state=tk.DISABLED)
            add_to_saved_commands(command)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
    else:
        messagebox.showwarning("Input Error", "Please enter a valid command.")

def add_to_saved_commands(command):
    existing = saved_commands_listbox.get(0, tk.END)
    if command not in existing:
        saved_commands_listbox.insert(tk.END, command)
        saved_commands_label.config(text="Command History")
        save_commands_to_file()

def save_commands_to_file():
    commands = saved_commands_listbox.get(0, tk.END)
    with open(SAVED_COMMANDS_FILE, "w") as f:
        for cmd in commands:
            f.write(cmd + "\n")

def load_saved_commands():
    if os.path.exists(SAVED_COMMANDS_FILE):
        with open(SAVED_COMMANDS_FILE, "r") as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]
        for cmd in lines:
            saved_commands_listbox.insert(tk.END, cmd)
        if lines:
            saved_commands_label.config(text="Command History")

def save_command():
    command = custom_command_entry.get().strip()
    if command:
        add_to_saved_commands(command)
        custom_command_entry.delete(0, tk.END)
    else:
        messagebox.showwarning("Input Error", "Please enter a valid command to save.")

def direct_run_command():
    command = custom_command_entry.get().strip()
    if command:
        execute_command(command)
        custom_command_entry.delete(0, tk.END)
    else:
        messagebox.showwarning("Input Error", "Please enter a valid command to run.")

def run_selected_command():
    try:
        selected_command = saved_commands_listbox.get(saved_commands_listbox.curselection())
        execute_command(selected_command)
    except tk.TclError:
        messagebox.showwarning("Selection Error", "Please select a command from the History list.")

def remove_selected_command():
    try:
        index = saved_commands_listbox.curselection()[0]
        saved_commands_listbox.delete(index)
        save_commands_to_file()
        if saved_commands_listbox.size() == 0:
            saved_commands_label.config(text="No Saved Commands")
    except IndexError:
        messagebox.showwarning("Selection Error", "Please select a command to remove.")

def clear_output():
    output_text.config(state=tk.NORMAL)
    output_text.delete("1.0", tk.END)
    output_text.config(state=tk.DISABLED)

def edit_selected_command():
    try:
        index = saved_commands_listbox.curselection()[0]
        current_command = saved_commands_listbox.get(index)
        new_command = simpledialog.askstring("Edit Command", "Enter the new command:", initialvalue=current_command)
        if new_command and new_command.strip():
            saved_commands_listbox.delete(index)
            saved_commands_listbox.insert(index, new_command.strip())
            save_commands_to_file()
        else:
            messagebox.showwarning("Input Error", "Invalid command entered.")
    except IndexError:
        messagebox.showwarning("Selection Error", "Please select a command to edit.")

# ------------------------- UI Setup -------------------------

# Initialize root window
root = tk.Tk()
root.withdraw()  # Hide window initially

# Check password before showing application
if not validate_password():
    root.destroy()
    exit()

# Configure window after successful validation
root.deiconify()
root.title("SCRCPY Controller")
root.geometry("620x600")
root.iconbitmap('hacker.ico')

# Apply styling
material_style = MaterialStyle()

# Main frame with reduced padding
top_frame = ttk.Frame(root, style="Material.TFrame")
top_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=10, pady=10)

# ----- Left Frame: SCRCPY Controls -----
left_frame = ttk.Frame(top_frame, style="Material.TFrame")
left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 6))

# Device selection with compact layout
ttk.Label(left_frame, text="Device Control", style="MaterialHeader.TLabel").pack(anchor="w", pady=(0, 8))

device_frame = ttk.Frame(left_frame, style="Material.TFrame")
device_frame.pack(fill=tk.X, pady=(0,2))

ttk.Label(device_frame, text="🖥️", style="Material.TLabel", width=3).pack(side=tk.LEFT)  # Fixed width label
device_var = tk.StringVar()
device_dropdown = ttk.Combobox(device_frame, textvariable=device_var, state="readonly", style="Material.TCombobox")
device_dropdown.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(4, 2))

refresh_btn = ttk.Button(device_frame, text="⟳", width=2, command=refresh_devices, style="Material.TButton")
refresh_btn.pack(side=tk.RIGHT)

# Initialize variables
fullscreen_var = tk.BooleanVar()
show_touches_var = tk.BooleanVar()
turn_screen_off_var = tk.BooleanVar()
rotate_screen_var = tk.BooleanVar()
no_control_var = tk.BooleanVar()
screen_recording_var = tk.BooleanVar()

audio_var = tk.StringVar(value=AUDIO_OPTIONS[0])
camera_var = tk.StringVar(value=CAMERA_OPTIONS[0])
quality_var = tk.StringVar(value=QUALITY_OPTIONS[3])
bitrate_var = tk.StringVar(value=BITRATE_OPTIONS[1])

# Stream Settings Section with compact layout
ttk.Label(left_frame, text="Stream Settings",style="MaterialHeader.TLabel").pack(anchor="w", pady=(2, 3))

settings_frame = ttk.Frame(left_frame, style="Material.TFrame")
settings_frame.pack(fill=tk.X, pady=(0, 3))

# Dropdowns with fixed-width labels for alignment
dropdowns = [
    ("🎙️", audio_var, AUDIO_OPTIONS),
    ("📷", camera_var, CAMERA_OPTIONS),
    ("🎞️", quality_var, QUALITY_OPTIONS),
    ("🎨", bitrate_var, BITRATE_OPTIONS)
]

for label_text, var, options in dropdowns:
    frame = ttk.Frame(settings_frame, style="Material.TFrame")
    frame.pack(fill=tk.X, pady=2)  # Reduced vertical spacing
    ttk.Label(frame, text=label_text, style="Material.TLabel", width=3).pack(side=tk.LEFT)  # Fixed width for alignment
    ttk.Combobox(frame, textvariable=var, values=options, state="readonly", style="Material.TCombobox").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(4, 0))

# Options Section with grid layout
ttk.Label(left_frame, text="Options", style="MaterialHeader.TLabel").pack(anchor="w", pady=(12, 6))  # Shorter title

options_frame = ttk.Frame(left_frame, style="Material.TFrame")
options_frame.pack(fill=tk.X)

options = [
    ("💢 Fullscreen", fullscreen_var),    # Shorter text
    ("👆 Touches", show_touches_var),      # Shorter text
    ("📴 Screen Off", turn_screen_off_var), # Shorter text
    ("🔃 Rotate", rotate_screen_var),      # Shorter text
    ("🧿 No Control", no_control_var),     # Shorter text
    ("⏺️ Record", screen_recording_var),   # Shorter text
]

# Create 2x3 grid layout for checkbuttons
for i, (text, var) in enumerate(options):
    row = i // 2
    col = i % 2
    cb = ttk.Checkbutton(options_frame, text=text, variable=var, style="Material.TCheckbutton")
    cb.grid(row=row, column=col, sticky="w", padx=4, pady=1)

# Configure grid columns to be equal width
options_frame.grid_columnconfigure(0, weight=1)
options_frame.grid_columnconfigure(1, weight=1)

# Action buttons
action_frame = ttk.Frame(left_frame, style="Material.TFrame")
action_frame.pack(fill=tk.X, pady=(16, 0))

ttk.Button(action_frame, text="Start SCRCPY", command=execute_commands, style="Material.TButton").pack(fill=tk.X, pady=(0, 4))
ttk.Button(action_frame, text="Stop SCRCPY", command=stop_scrcpy, style="MaterialSecondary.TButton").pack(fill=tk.X)

# ----- Right Frame: Command Controls -----
right_frame = ttk.Frame(top_frame, style="Material.TFrame")
right_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(8, 0))

ttk.Label(right_frame, text="Hide Indicetors", style="MaterialHeader.TLabel").pack(anchor="w", pady=(0, 4))

# Quick Actions
quick_actions_frame = ttk.Frame(right_frame, style="Material.TFrame")
quick_actions_frame.pack(fill=tk.X, pady=(0, 6))
ttk.Button(quick_actions_frame, text="Disable Camera/Mic",
           command=lambda: execute_command("adb shell cmd device_config put privacy camera_mic_icons_enabled false default"),
           style="Material.TButton").pack(fill=tk.X, pady=(0, 4))
ttk.Button(quick_actions_frame, text="Disable systme notifications",
           command=lambda: execute_command("adb shell appops set com.android.systemui POST_NOTIFICATION ignore"),
           style="Material.TButton").pack(fill=tk.X)

# Custom Command Section with optimized layout
ttk.Label(right_frame, text="Input Command ", style="MaterialHeader.TLabel").pack(anchor="w", pady=(12, 4))

command_frame = ttk.Frame(right_frame, style="Material.TFrame")
command_frame.pack(fill=tk.X, pady=(0, 8))

custom_command_entry = ttk.Entry(command_frame, font=("Consolas", 9))  # Monospace font for commands
custom_command_entry.pack(fill=tk.X, pady=(0, 8))
custom_command_entry.bind('<Return>', lambda e: direct_run_command())

cmd_buttons_frame = ttk.Frame(command_frame, style="Material.TFrame")
cmd_buttons_frame.pack(fill=tk.X)
ttk.Button(cmd_buttons_frame, text="Run", command=direct_run_command, style="Material.TButton", width=20).pack(side=tk.LEFT, padx=(0, 2))
ttk.Button(cmd_buttons_frame, text="Save", command=save_command, style="MaterialSecondary.TButton", width=20).pack(side=tk.RIGHT, padx=2)

# Saved Commands Section with optimized layout
saved_commands_label = ttk.Label(right_frame, text="Command History", style="MaterialHeader.TLabel")
saved_commands_label.pack(anchor="w", pady=(0, 8))

saved_commands_frame = ttk.Frame(right_frame, style="Material.TFrame")
saved_commands_frame.pack(fill=tk.BOTH, expand=True)

saved_commands_listbox = tk.Listbox(saved_commands_frame,
                                   bg=COLOR_SURFACE,
                                   fg=COLOR_TEXT_PRIMARY,
                                   selectbackground=COLOR_PRIMARY,
                                   selectforeground=COLOR_TEXT_PRIMARY,
                                   font=("Consolas", 9),
                                   height=6,  # Reduced height since output is now at bottom
                                   borderwidth=0,
                                   highlightthickness=1,
                                   highlightbackground=COLOR_SECONDARY)
saved_commands_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# Add scrollbar to saved commands
saved_commands_scrollbar = ttk.Scrollbar(saved_commands_frame, command=saved_commands_listbox.yview)
saved_commands_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
saved_commands_listbox.config(yscrollcommand=saved_commands_scrollbar.set)

# Buttons for saved commands with compact layout
saved_cmd_buttons = ttk.Frame(right_frame, style="Material.TFrame")
saved_cmd_buttons.pack(fill=tk.X, pady=4)
ttk.Button(saved_cmd_buttons, text="Run Selected", command=run_selected_command, style="Material.TButton", width=20).pack(side=tk.LEFT, padx=(0, 2))
ttk.Button(saved_cmd_buttons, text="Clear", command=clear_output, style="MaterialSecondary.TButton", width=20).pack(side=tk.RIGHT, padx=2)

# Bottom output section with full width
bottom_frame = ttk.Frame(root, style="Material.TFrame")
bottom_frame.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True, padx=10, pady=10)

ttk.Label(bottom_frame, text="Output", style="MaterialHeader.TLabel").pack(anchor="w", pady=(0, 4))

output_frame = ttk.Frame(bottom_frame, style="Material.TFrame")
output_frame.pack(fill=tk.BOTH, expand=True)

output_text = tk.Text(output_frame,
                      height=10,  # Increased height for bottom section
                      wrap=tk.WORD,
                      state=tk.DISABLED,
                      bg=COLOR_SURFACE,
                      fg=COLOR_TEXT_PRIMARY,
                      font=("Consolas", 10),  # Slightly larger font
                      padx=8,  # Increased padding
                      pady=8,
                      borderwidth=0,
                      highlightthickness=1,
                      highlightbackground=COLOR_SECONDARY,
                      insertbackground=COLOR_TEXT_PRIMARY)  # Cursor color
output_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
scrollbar = ttk.Scrollbar(output_frame, command=output_text.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
output_text.config(yscrollcommand=scrollbar.set)

# Configure success/error tags with enhanced visibility
output_text.tag_configure('success', foreground=COLOR_SUCCESS, font=("Consolas", 9, "bold"))
output_text.tag_configure('error', foreground=COLOR_ERROR, font=("Consolas", 9, "bold"))

# Context menu setup
context_menu = tk.Menu(root, tearoff=0, bg=COLOR_SURFACE, fg=COLOR_TEXT_PRIMARY)
context_menu.add_command(label="Edit Command", command=edit_selected_command)
context_menu.add_command(label="Remove Command", command=remove_selected_command)

def show_context_menu(event):
    try:
        index = saved_commands_listbox.nearest(event.y)
        saved_commands_listbox.select_clear(0, tk.END)
        saved_commands_listbox.select_set(index)
        context_menu.post(event.x_root, event.y_root)
    except Exception as e:
        print(f"Error: {e}")

saved_commands_listbox.bind("<Button-3>", show_context_menu)

# Update device list and load saved commands
update_device_list()
load_saved_commands()

root.mainloop()

