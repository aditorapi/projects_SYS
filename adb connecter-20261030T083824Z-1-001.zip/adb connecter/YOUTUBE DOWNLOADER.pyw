import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import subprocess
import threading
import re
import os
import datetime

class YouTubeDownloaderApp:
    def __init__(self, master):
        self.master = master
        master.title("YouTube Downloader")
        master.geometry("600x600")
        
        self.url_label = tk.Label(master, text="YouTube URL:", font=("Helvetica", 12, "bold"))
        self.url_label.pack(pady=5)
        self.url_entry = tk.Entry(master, width=50, font=("Helvetica", 12))
        self.url_entry.pack(pady=5)

        # Options frame
        options_frame = tk.Frame(master)
        options_frame.pack(pady=10)

        # Video quality option
        self.quality_label = tk.Label(options_frame, text="Video Quality:", font=("Helvetica", 12, "bold"))
        self.quality_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.quality_var = tk.StringVar(value="720p")
        qualities = ["1080p", "720p", "480p", "360p", "240p"]
        self.quality_menu = tk.OptionMenu(options_frame, self.quality_var, *qualities)
        self.quality_menu.config(font=("Helvetica", 12))
        self.quality_menu.grid(row=0, column=1, padx=5, pady=5)

        # Download format option (Video or Audio)
        self.format_label = tk.Label(options_frame, text="Download Format:", font=("Helvetica", 12, "bold"))
        self.format_label.grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.format_var = tk.StringVar(value="Video")
        self.video_radio = tk.Radiobutton(options_frame, text="Video", variable=self.format_var, value="Video",
                                          font=("Helvetica", 12), command=self.update_video_format_state)
        self.video_radio.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        self.audio_radio = tk.Radiobutton(options_frame, text="Audio", variable=self.format_var, value="Audio",
                                          font=("Helvetica", 12), command=self.update_video_format_state)
        self.audio_radio.grid(row=1, column=2, padx=5, pady=5, sticky=tk.W)

        # Video format option for video downloads
        self.video_format_label = tk.Label(options_frame, text="Video Format:", font=("Helvetica", 12, "bold"))
        self.video_format_label.grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.video_format_var = tk.StringVar(value="mp4")
        video_formats = ["mp4", "mkv"]
        self.video_format_menu = tk.OptionMenu(options_frame, self.video_format_var, *video_formats)
        self.video_format_menu.config(font=("Helvetica", 12))
        self.video_format_menu.grid(row=2, column=1, padx=5, pady=5)
        
        # Thumbnail download option
        self.thumbnail_var = tk.IntVar()
        self.thumbnail_check = tk.Checkbutton(options_frame, text="Download Thumbnail", variable=self.thumbnail_var, font=("Helvetica", 12, "bold"))
        self.thumbnail_check.grid(row=3, column=0, padx=5, pady=5, sticky=tk.W)

        # Default download location option
        self.location_label = tk.Label(options_frame, text="Default Download Location:", font=("Helvetica", 12, "bold"))
        self.location_label.grid(row=4, column=0, padx=5, pady=5, sticky=tk.W)
        self.location_var = tk.StringVar(value=os.getcwd())
        self.location_entry = tk.Entry(options_frame, textvariable=self.location_var, width=40, font=("Helvetica", 12))
        self.location_entry.grid(row=4, column=1, padx=5, pady=5)
        self.browse_button = tk.Button(options_frame, text="Browse", command=self.browse_location, font=("Helvetica", 12, "bold"))
        self.browse_button.grid(row=4, column=2, padx=5, pady=5)
        
        # Preview / Progress
        self.preview_label = tk.Label(master, text="Preview / Progress:", font=("Helvetica", 12, "bold"))
        self.preview_label.pack(pady=5)
        self.progress = ttk.Progressbar(master, orient="horizontal", length=500, mode="determinate")
        self.progress.pack(pady=5)

        # Action buttons
        button_frame = tk.Frame(master)
        button_frame.pack(pady=10)
        self.download_button = tk.Button(button_frame, text="Start Download", command=self.start_download, font=("Helvetica", 12, "bold"))
        self.download_button.grid(row=0, column=0, padx=10)
        self.cancel_button = tk.Button(button_frame, text="Cancel Download", command=self.cancel_download, font=("Helvetica", 12, "bold"))
        self.cancel_button.grid(row=0, column=1, padx=10)

        # Download History
        history_frame = tk.Frame(master)
        history_frame.pack(pady=10, fill=tk.BOTH, expand=True)
        self.history_label = tk.Label(history_frame, text="Download History:", font=("Helvetica", 12, "bold"))
        self.history_label.pack(anchor="w", padx=5)
        self.history_listbox = tk.Listbox(history_frame, height=8, font=("Helvetica", 12))
        self.history_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        history_scrollbar = tk.Scrollbar(history_frame)
        history_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.history_listbox.config(yscrollcommand=history_scrollbar.set)
        history_scrollbar.config(command=self.history_listbox.yview)

        self.download_thread = None
        self.process = None
        self.current_url = ""
        
        # Load existing download history if exists
        self.load_history()
        
        # Initialize video format state
        self.update_video_format_state()

    def update_video_format_state(self):
        if self.format_var.get() == "Video":
            self.video_format_menu.config(state=tk.NORMAL)
            self.video_format_label.config(state=tk.NORMAL)
        else:
            self.video_format_menu.config(state=tk.DISABLED)
            self.video_format_label.config(state=tk.DISABLED)
        
    def browse_location(self):
        directory = filedialog.askdirectory()
        if directory:
            self.location_var.set(directory)
        
    def start_download(self):
        url = self.url_entry.get().strip()
        if not url:
            messagebox.showerror("Error", "Please enter a YouTube URL.")
            return
        self.current_url = url
        self.progress['value'] = 0
        self.download_button.config(state=tk.DISABLED)
        self.download_thread = threading.Thread(target=self.download_video, args=(url,))
        self.download_thread.start()
        
    def download_video(self, url):
        cmd = ["yt-dlp", url]
        
        # Set download format based on selection
        if self.format_var.get() == "Video":
            quality = self.quality_var.get()
            video_format = self.video_format_var.get()
            cmd.extend(["-f", f"bestvideo[height<={quality.rstrip('p')}]+bestaudio/best"])
            cmd.extend(["--recode-video", video_format])
        elif self.format_var.get() == "Audio":
            cmd.append("--extract-audio")
        
        # Add thumbnail option if selected
        if self.thumbnail_var.get():
            cmd.append("--write-thumbnail")
        
        # Set output directory
        download_dir = self.location_var.get()
        output_template = os.path.join(download_dir, "%(title)s.%(ext)s")
        cmd.extend(["-o", output_template])
        
        # For progress, use --newline option for yt-dlp
        cmd.append("--newline")
        
        try:
            self.process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
            for line in self.process.stdout:
                match = re.search(r'(\d+\.\d+)%', line)
                if match:
                    percent = float(match.group(1))
                    self.update_progress(percent)
            self.process.stdout.close()
            self.process.wait()
            self.download_complete()
        except Exception as e:
            messagebox.showerror("Error", str(e))
            self.download_button.config(state=tk.NORMAL)
            
    def update_progress(self, percent):
        self.progress['value'] = percent
        self.master.update_idletasks()
        
    def download_complete(self):
        messagebox.showinfo("Download Complete", "The download has finished.")
        self.download_button.config(state=tk.NORMAL)
        self.update_history(self.current_url)
        
    def cancel_download(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            messagebox.showinfo("Cancelled", "The download has been cancelled.")
            self.download_button.config(state=tk.NORMAL)
        
    def update_history(self, url):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        history_line = f"{timestamp} - {url}"
        # Append to history file in the default download location
        history_file = os.path.join(self.location_var.get(), "download_history.txt")
        try:
            with open(history_file, "a", encoding="utf-8") as f:
                f.write(history_line + "\n")
        except Exception as e:
            messagebox.showerror("Error", f"Could not update history file: {e}")
        # Update the listbox
        self.history_listbox.insert(tk.END, history_line)
        
    def load_history(self):
        history_file = os.path.join(self.location_var.get(), "download_history.txt")
        if os.path.exists(history_file):
            try:
                with open(history_file, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                    for line in lines:
                        self.history_listbox.insert(tk.END, line.strip())
            except Exception as e:
                messagebox.showerror("Error", f"Could not load history: {e}")
        
if __name__ == "__main__":
    root = tk.Tk()
    app = YouTubeDownloaderApp(root)
    root.mainloop()