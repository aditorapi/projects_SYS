@echo off
adb start-server
adb wait-for-device
adb tcpip 5555
echo ADB Wireless Mode Enabled!

:: Device ko specified IP se connect karna
adb connect 192.168.175.167:5555
echo Device connected successfully to 192.168.175.167:5555

pause
